To run the code, cd into the root directory of the Oikos folder. Then, run the following command "npm run devStart".
